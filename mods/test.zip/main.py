import api

api.mod_name('test')


############## images ###############

api.register_image('test:human', 'human.png')
api.register_image('test:zombie', 'zombie.png')
api.register_image('test:sketeton', 'skeleton.png')


############## tiles ###############


############## objects ###############

class EntityZombie(api.Entity):
	entity_id = 'test:zombie'
	speed = 1
	width = height = 0.8

	def update(self, dtime):
		self.move_to(self.x + self.speed * dtime, self.y)

api.register_entity('test:zombie', EntityZombie)

