import api

api.mod_name('default')


############## images ###############

api.register_image('default:wall', 'wall.png')
api.register_image('default:floor', 'floor.png')
api.register_image('default:player', 'player.png')
api.register_image('default:door_closed', 'door_closed.png')
api.register_image('default:door_opened', 'door_opened.png')
api.register_image('default:selection', 'selection.png')
api.register_image('default:empty', 'empty.png')

################ tiles ##################

class WallTile(api.Tile):
	is_wall = True
	blocks_view = True


class FloorTile(api.Tile):
	is_wall = False
	blocks_view = False


class DoorTile(api.Tile):
	is_wall = True
	blocks_view = True
	image = 'default:door_closed'


api.register_tile('default:wall', WallTile)
api.register_tile('default:floor', FloorTile)
api.register_tile('default:door', DoorTile)

############### objects ################

#api.register_entity('default:entity', {
#	})
